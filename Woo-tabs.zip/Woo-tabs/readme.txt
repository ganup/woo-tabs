=== WOO Tabs ===
Contributors: Ganesh Paygude
Tags: Woocommerce
Requires at least: 3.2
Tested up to: 4.4.1
Stable tag: 1.0
License: GPLv2
Author: Ganesh Paygude

Woo-tabs adds tabs to product single details page.

== Description ==

Woo Tabs allow you to add your custom tab for product info on product details page.

Major features in Woo-Tabs include:

* Allow to create tabs
* Allow to assign multiple tabs for a product. 

== Installation ==

Upload the Woo-tabs plugin to your website, Activate it,Start by creating the woo-tabs.
